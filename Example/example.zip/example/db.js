module.exports = function() {
  return {
    profiles: require('./profiles.json'),
    tweets: require('./tweets.json')
  }
}